var router = require('express').Router();

router.use('/AgrotechSoft/api/v1', require('./api'));

module.exports = router;
